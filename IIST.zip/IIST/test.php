<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="one">
            <!-- Welcome

        <h1>Dhaka Polytechnic Institute</h1> -->

        <?php
        //echo '<h1>Hello World!</h1>';
        $num1=40;
        $num2=56;
        $result=$num1+$num2;
        echo 'Result = '.$result;
        ?>
    </div>
    <div class="two">
        <?php
        echo '<h5>Menu</h5>';
        ?>
    </div>
</body>
</html>