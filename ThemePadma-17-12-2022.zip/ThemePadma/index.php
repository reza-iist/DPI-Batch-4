<?php get_header(); ?>
<!-- Hero Part Start -->
<section class="container hero text-center">
  <div class="row hero_title">
    <?php dynamic_sidebar('h_title'); ?>
  </div>
  <div class="row hero_card mt-5">
        <div class="col-sm-4">
          <div class="card" style="width: 18rem;">
              <?php dynamic_sidebar('card_img');?>
                <div class="card-body">
                <?php dynamic_sidebar('card_body');?>
                </div>
            </div>
        </div>
    <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
              <?php dynamic_sidebar('card_img');?>
                <div class="card-body">
                <?php dynamic_sidebar('card_body');?>
                </div>
            </div>
    </div>
    <div class="col-sm-4">
    <div class="card" style="width: 18rem;">
              <?php dynamic_sidebar('card_img');?>
                <div class="card-body">
                <?php dynamic_sidebar('card_body');?>
                </div>
            </div>
    </div>
  </div>
</section>
<!-- Hero Part End -->
<!-- Photo Part Start -->
<section class="container photo text-center mt-5 mb-5">
  <div class="row">
    <div class="col-sm-5">
      <img src="<?php echo get_template_directory_uri().'/assets/images/bg_line_green2.png'?>" alt="">
    </div>
    <div class="col-sm-2">
      <h4>Recent Photos</h4>
      <p>Some latest project pictures</p>
    </div>
    <div class="col-sm-5">
    <img src="<?php echo get_template_directory_uri().'/assets/images/download.png'?>" alt="">
    </div>
  </div>
  <div class="row">
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg1');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext1');?>
            </div>
          </div>                                                              
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg2');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext2');?>
            </div>
          </div>
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg3');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext3');?>
            </div>
          </div>                                                              
    </div>
    <div class="col-sm-3">
          <div class="card h-100" style="width: 16rem;">
            <?php dynamic_sidebar('photoimg4');?>
            <div class="card-body">
              <?php dynamic_sidebar('phototext4');?>
            </div>
          </div>                                                              
    </div>
  </div>
</section>
<!-- Photo Part End -->
<!-- News part start -->
<section class="container news mb-5 mt-5">
  <div class="row">
  <div class="col-sm-5">
      <img src="<?php echo get_template_directory_uri().'/assets/images/bg_line_green2.png'?>" alt="">
    </div>
    <div class="col-sm-2">
      <h5>NEWS & EVENTS</h5>
      <p>CLICK HERE TO VIEW ALL</p>
    </div>
    <div class="col-sm-5">
    <img src="<?php echo get_template_directory_uri().'/assets/images/download.png'?>" alt="">
    </div>
  </div>
  </div>
  <div class="row">
    <?php $qry2 = new WP_Query([
      'post_type'=>'post',
      'category_name'=>'news',
    ]);?>
  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  
  <div class="carousel-inner">

    <?php 
    $x=0;
    while($qry2->have_posts()){$qry2->the_post(); 
    $x++;
    ?>
    <div class="carousel-item <?= ($x==1)?'active':''?>">
        <?php the_title();?>
      
    </div>
    <?php } ?>

   
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>  
  </div>
</section>
<!-- News part end -->
<?php get_footer();?>