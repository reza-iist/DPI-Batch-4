<?php get_header('others');?>

<section class="container text-center xx">
<h1>Page not found</h1>
</section>

<?php get_footer();?>