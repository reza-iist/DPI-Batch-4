<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/assets/css/style_others.css' );
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );

register_sidebar(array(
    'name'=>'Logo Top Right ',
    'id'=>'ltr',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Hero Title ',
    'id'=>'h_title',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Hero Crad Image-1 ',
    'id'=>'card_img',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Hero Crad Body-1 ',
    'id'=>'card_body',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Image-1 ',
    'id'=>'photoimg1',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Text-1 ',
    'id'=>'phototext1',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Image-2 ',
    'id'=>'photoimg2',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Text-2 ',
    'id'=>'phototext2',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Image-3 ',
    'id'=>'photoimg3',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Text-3 ',
    'id'=>'phototext3',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Image-4 ',
    'id'=>'photoimg4',
    'before_widget'  => '',
	'after_widget'   => "",
) );
register_sidebar(array(
    'name'=>'Photo Text-4 ',
    'id'=>'phototext4',
    'before_widget'  => '',
	'after_widget'   => "",
) );

register_nav_menus( array(
    'TM'=>'Primary',
) );


register_sidebar(array(
    'name'=>'footer left ',
    'id'=>'footer_left',
    'before_widget'  => '',
	'after_widget'   => "",
) );

register_sidebar(array(
    'name'=>'footer right ',
    'id'=>'footer_right',
    'before_widget'  => '',
	'after_widget'   => "",
) );