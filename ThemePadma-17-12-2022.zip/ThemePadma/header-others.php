<!DOCTYPE html>
<html <?php language_attributes( );?>>
<head>
    <meta charset="<?php bloginfo( 'charset' )?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head();?>
</head>
<body>
 <!-- Header part start -->
 
 <!-- Header part end -->
 <!-- Logo part start -->
 <section class="container-fluid logo pl-2">
    <div class="row">
        <div class="col-sm-6 logo_left">
            <?php the_custom_logo();?>
        </div>
        <div class="col-sm-6 logo_right text-end">
            <?php dynamic_sidebar('ltr');?>
        </div>
    </div>
 </section>
 <!-- Logo part end -->
<!-- Menu part start -->
<section class="container-fluid mt-0 ">
  <div class="container navbar-expand ">
  <?php 
        wp_nav_menu(array(
            'theme_location'=>'TM',
            'menu_class'=>'navbar-nav menu-2'
        ) );
        ?>
  </div>
</section>
<!-- Menu part end -->
<section class="container search">
  <div class="row">
    <div class="col-sm-8"></div>
    <div class="col-sm-4 text-end">
      <form action="">
        <input type="text" value="<?php echo get_search_query(); ?>" name="s">
        <button>Search</button>
      </form>
    </div>
  </div>
</section>