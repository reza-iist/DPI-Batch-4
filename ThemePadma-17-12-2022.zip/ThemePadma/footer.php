<footer class="container-fluid footer_main mt-5">
<div class="row">
  <div class="col-lg-6 footer_left" style="width: 20rem;" >
    <?php dynamic_sidebar('footer_left'); ?>
  </div>
  <div class="col-lg-6 footer_right " style="width: 25rem;">
      <?php dynamic_sidebar('footer_right') ?>
  </div>
</div>

</footer>





<?php wp_footer();?>
</body>
</html>