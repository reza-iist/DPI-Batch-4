<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$num1=156;
$num2='156';
$result=$num1*$num2;
?>

<div class="one">
Welcome

<h1>ECC</h1>

<?php
echo 'This is my first program in PHP';
?>
</div>

<div class="new">
    <h5>IIST</h5>
</div>


<div class="tree">
<?php


echo 'The Muliplicaion= '.$result;
if($num1==$num2){
    echo '<br>True<br>';
}else{
    echo '<br> False<br>';
}
var_dump($num1);
print_r($result);




?>

<?php
$t = date("H");

if ($t < "1") {
  echo "<br>Have a good day!";
}else{
    echo "<br>Have a good evening!<br>";
}
?>

<?php
$i = 1; 

while
 ($i <= 6) 
{

  echo $i;
  $i++;
}

?>

</div>

</body>
</html>